# Gesture_Detection
SmartHome-like program that will do certain things depending on the gesture.
